#ifndef GRSOASM_H
#define GRSOASM_H
/* really same as the mmx asm.h */
/* made just in case something must be changed */
#include "grso.h"

extern void grsoP1024ASM (u64 *x) ;

extern void grsoQ1024ASM (u64 *x) ;

#endif 
